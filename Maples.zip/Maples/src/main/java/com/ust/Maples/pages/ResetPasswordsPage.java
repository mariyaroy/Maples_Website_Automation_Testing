package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: ARDRA A

public class ResetPasswordsPage 
{
	WebDriver driver;
	ReusableFunctions reusableFunctions;
	
	@FindBy(id="user_login")
	public WebElement Uname;
	
	@FindBy(xpath="//*[@id=\"post-11\"]/div/div/div/div/div/div/div/div/form/p[3]/button")
	public WebElement resetButton;
	
	@FindBy(xpath="//*[@id=\"post-11\"]/header/h1")
	public WebElement resetpasswordTitle;
	
	public ResetPasswordsPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		PageFactory.initElements(driver, this);
		reusableFunctions = new ReusableFunctions(driver);
	}
	
	public ResetPasswordsPage insertTxt(WebElement el,String txt)
	{
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.insertText(txt, el);
		return this;
	}
	
	public boolean checkUrl(String url)
	{
		return reusableFunctions.checkUrl(url);
	}
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	public Object clickElementAndReturnDriver(WebElement el, Object o)   {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
		return o;
		
	}
	
	
	

}
