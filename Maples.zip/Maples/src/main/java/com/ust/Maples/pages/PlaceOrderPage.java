package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

// AUTHOR: MARIYA ROY

public class PlaceOrderPage {
	
	public WebDriver driver;

	public PlaceOrderPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}

}
