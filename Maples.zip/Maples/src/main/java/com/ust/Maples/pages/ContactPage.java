package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: MARIYA ROY

public class ContactPage {

	public WebDriver driver;
	public ReusableFunctions reusableFunctions;

	public ContactPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);	
	}

	//@FindBy (xpath = "//div[contains(@class, 'contact-form')]//h3")
	@FindBy (xpath = "(//h2[contains(@class,'elementor-heading-title')])[1]")
	public WebElement heading;

	//@FindBy (name = "your-name")
	@FindBy (id = "form-field-name")
	public WebElement name;

	//@FindBy (name = "your-email")
	@FindBy (id = "form-field-email")
	public WebElement email;

	@FindBy (xpath = "//input[@id='form-field-field_9b3df45']")
	public WebElement phone;

	@FindBy (name = "your-subject")
	public WebElement subject;

	//@FindBy (name = "your-message")
	@FindBy (id = "form-field-message")
	public WebElement message;

	@FindBy (css = "p > input")
	public WebElement submitBtn;

	@FindBy (css = "div > button")
	public WebElement sendBtn;

	@FindBy (css = "div.elementor-message-success")
	public WebElement successMsg;

	public boolean getUrl(String url) {
		if (url == null) {
			throw new NullPointerException("URL is null");
		}
		return reusableFunctions.checkUrl(url);
	}

	public void sendText(String text, WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.insertText(text, el);
	}

	public void clickElement(WebElement el)  {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}
}
