package com.ust.Maples.reusable;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableFunctions {
	
	public WebDriver driver;
	public Actions actions;

	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // EXPLICIT WAIT
		wait.until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}

	public String getTextString(WebElement element) {
		String text = element.getText();
		return text;
	}

	public void scroll(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public boolean checkUrl(String url) {
		if ((driver.getCurrentUrl()).equals(url)) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean checkTitle(String title) {
		if ((driver.getTitle()).equals(title)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isDisplayed(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}
	
	public void insertText(String text, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // EXPLICIT WAIT
			wait.until(d->element.isDisplayed()); // USING LAMBDA FUNCTION
			element.clear();
			element.sendKeys(text);
		}
		catch (StaleElementReferenceException e) {
			throw new RuntimeException("Element is stale and not attached to the DOM.");
		}
	}
	
	public void actionClick(WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.click();
		actions.perform();
	}
	
	public boolean isEnabled(WebElement element) {
		if (element.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isTextContained(String name, WebElement element) {
		if((element.getText()).contains(name)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean isNotDisplayed(WebElement element) {
	    try {
	        return !element.isDisplayed();
	    } catch (NoSuchElementException e) {
	        return true;
	    }
	}
	
	public void jsClick(WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].click();", element);
	}
	
	public boolean verifyEmail(String email) {
		if(email.matches("^[a-zA-Z][a-zA-Z0-9._]*@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
			return true;
		}
		return false;	
	}
	
	public boolean verifyName(String name) {
		if(name.matches("^[a-zA-Z]+\\s[a-zA-Z]*")) {
			return true;
		}
		return false;	
	}
	
	public void switchWindow() {
		String currentHandle = driver.getWindowHandle(); // FETCHING CURRENT WINDOW
		Set<String> handles = driver.getWindowHandles(); // GETTING ALL WINDOW HANDLES THAT ARE AVAILABELE
		for(String actual: handles) {
			if(!actual.equalsIgnoreCase(currentHandle)) {

				driver.switchTo().window(actual); // SWITCHING TAB
			}
		}
	}
	
	public void hover(WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}
	
	public String getUrl() {
		return driver.getCurrentUrl();
	}
	

}
