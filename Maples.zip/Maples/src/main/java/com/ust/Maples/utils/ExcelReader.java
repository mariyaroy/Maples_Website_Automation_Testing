package com.ust.Maples.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//--------------------EXCEL SHEET READER IMPLEMENTATION--------------------//

public class ExcelReader {

	public static String[][] getExcelData(String path, String sheetName) {

		try {
			FileInputStream fis = new FileInputStream(new File(path));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int rowCount = sheet.getPhysicalNumberOfRows(); // TOTAL NUMBER OF ROWS IN THE SHEET
			int columnCount = sheet.getRow(0).getPhysicalNumberOfCells(); // TOTAL NUMBER OF COLUMNS IN THE SHEET

			String[][] data = new String[rowCount][columnCount];
			DataFormatter df = new DataFormatter();
			for(int i = 0; i < rowCount; i++) {
				for(int j = 0; j < columnCount; j++) {
					data[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j)); // STORING DATA INTO TWO DIMENSIONAL ARRAY
				}
			}

			workbook.close();
			fis.close();
			
			return data;
		}
		catch (IOException e) {
			System.err.println("Failed to read Excel file: " + e.getMessage());
		}
		
		return null;
	}


}
