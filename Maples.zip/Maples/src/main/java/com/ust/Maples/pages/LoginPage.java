package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: AAFIYA MOL S A

public class LoginPage 
{
	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public LoginPage(WebDriver driver){
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver=driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);//
	}

	
	@FindBy(xpath="//h1[@itemprop='headline']")
	//@FindBy(xpath = "//header[@class='entry-header']")
	public WebElement myAccTitle; //My Account
	@FindBy(id="username")
	public WebElement uname;
	
	@FindBy(id="password")
	public WebElement pswd;
	
	@FindBy(name="login")
	public WebElement logButton;
	
	@FindBy(linkText = "Logout")
	public WebElement logoutButton;
	
	@FindBy(xpath="//div[@class='woocommerce-MyAccount-content']")
	public WebElement successText;
	
	@FindBy(xpath="//div[@class='woocommerce-notices-wrapper']")
	public WebElement nullLoginText;
	
	@FindBy(xpath="//ul[@role='alert']")
	public WebElement errorText;
	
	@FindBy(linkText="Lost your password?")
	public WebElement lostPassword;
	
	public void sendText(String text, WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.insertText(text, el);	
	}
	
	public void clickButton(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.clickElement(el);
	}
	public boolean getTitle(String title) {
		return reusableFunctions.checkTitle(title);
	}
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	public Object clickElementAndReturnDriver(WebElement el, Object o) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
		return o;
		
	}

}