package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: ARDRA A

public class SearchResultPage 
{
	WebDriver driver;
	ReusableFunctions reusableFunctions;
		
	@FindBy(xpath="//span[contains(text(),'Amul')]")
	public WebElement BrandName;
	
	@FindBy(linkText="Amul Cacao 99% 125 Gm")
	public WebElement ProductBrandName;
	
	//@FindBy(xpath="/html/body/div[2]/div/div[2]/div[1]/div/header/h1")
	@FindBy(xpath="//h1[contains(text(),'Search Results for: cheese')]")
	public WebElement SearchResultTitle;
	
	//@FindBy(xpath="//*[@id=\"archive-product\"]/div/p")
	@FindBy(xpath="//*[@id=\"content\"]/div/div/div[2]/div/div[2]/div/div/div")
	public WebElement SearchInvalidResult;
	
	//@FindBy(className="entry-title")
	@FindBy(xpath="//*[@id=\"content\"]/div/div/div[1]/div/div/div/div[1]/div/h1")
	public WebElement SearchNullResult;

	public SearchResultPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	public boolean checkSearchResultUrl(String url)
	{
		return reusableFunctions.checkUrl(url);
	} 
	
	public String ResultgetTitle(WebElement el)
	{
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
		
	}
	
	//--------------------BRAND FUNCTIONS --------------------//
	
	public SearchResultPage clickBrandName(WebElement el)
	{
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.clickElement(el);
		return this;
	}	
}
