package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: ARDRA A

public class ForgetPasswordPage
{
	public WebDriver driver;
	public ReusableFunctions reusableFunctions;
	
	public ForgetPasswordPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="user_login")
	public WebElement resetUsername;
	
	@FindBy(xpath="//*[@id=\"post-11\"]/div/div/div/div/div/div/div/div/form/p[3]/button")
	public WebElement resetPasswordButton;
	
	
	
	
	public void clickElement(WebElement el)  {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
	}
	
	public void sendText(String text, WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.insertText(text, el);	
	} 
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	

}
