package com.ust.Maples.utils;

import java.io.FileReader;
import java.util.Properties;

//--------------------CONFIGURATION READER IMPLEMENTATION--------------------//

public class ConfigReader {
	
	private static Properties prop;
	private static FileReader file;
	
	// PATH OF THE PROPERTIES FILE
	public static String PATH = System.getProperty("user.dir") + "\\src\\test\\resources\\Config\\config.properties";
	
	public static Properties getPropertyValue() {
		
		if(prop == null) {
			prop = new Properties();
		} 
		
		try {
			file = new FileReader(PATH);
			prop.load(file);
		}
		catch(Exception e) {
			System.out.println("Properties file not found!");
			e.printStackTrace();
		}
		return prop;
	}


}
