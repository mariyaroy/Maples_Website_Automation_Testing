package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: AAFIYA MOL S A

public class AddressesPage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public AddressesPage(WebDriver driver) {
		if (driver == null) {
			throw new NullPointerException("WebDriver instance is null");
		}
		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	//billingAddress
	@FindBy(linkText = "Addresses")
	public WebElement add;
	
	@FindBy (xpath = "(//a[@class='edit'])[1]")
	public WebElement billingAdd;
	
	@FindBy (id = "billing_first_name")
	public WebElement fname;
	
	@FindBy (id = "billing_last_name")
	public WebElement lname;
	
	@FindBy (id = "billing_address_1")
	public WebElement address;
	
	@FindBy (id = "billing_city")
	public WebElement city;
	
	@FindBy(id="billing_state")
	public WebElement selectstate;
	
	public void selectState(String s)
	{
	Select selecobj=new Select(selectstate);
	selecobj.selectByVisibleText(s);
	}
	
	@FindBy (xpath = "//p[@id='billing_state_field']/span/span/span/span")
	public WebElement state;
	
	@FindBy (xpath = "//input[@class='select2-search__field']")
	public WebElement stateText;
	
	@FindBy (id = "billing_postcode")
	public WebElement pincode;
	
	@FindBy (id = "billing_phone")
	public WebElement phone;
	
	@FindBy (id = "billing_email")
	public WebElement email;
	
	@FindBy (name = "save_address")
	public WebElement saveButton;
	
	@FindBy (xpath = "//div[@role='alert']")
	public WebElement addSuccessText;
	
	//shippingAddress
	@FindBy (xpath = "(//a[@class='edit'])[2]")
	public WebElement shippingAdd;
	
	@FindBy (name = "shipping_first_name")
	public WebElement shippingfname;
	
	@FindBy (id = "shipping_last_name")
	public WebElement shippinglname;
	
	@FindBy (id = "shipping_address_1")
	public WebElement shippingaddress;
	
	@FindBy (id = "shipping_city")
	public WebElement shippingcity;
	
	@FindBy (id = "select2-shipping_state-container")
	public WebElement shippingStateoption;
	
	 @FindBy (xpath = "//input[@class='select2-search__field']")
	 public WebElement shippingstate;
	
	@FindBy (id = "shipping_postcode")
	public WebElement shippingpostcode;
	
	@FindBy (id= "shipping_postcode_field")
	public WebElement saveAddButton;
	
	@FindBy (xpath = "//div[@role='alert']")
	public WebElement shipSuccessText;
	
	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}
	
	public void sendText(String text, WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.insertText(text, el);
	}
		
	public void clickElement(WebElement el)  {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

}
