package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class AddToCartPage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public AddToCartPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}

	@FindBy (className = "entry-title")
	public WebElement heading;

	//@FindBy (xpath = "(//td[@class='product-remove'])[1]/a")
	@FindBy (css = "td.product-remove > a.remove")
	public WebElement removeIcon;

	//@FindBy (xpath = "(//input[@class='input-text qty text'])[1]")
	@FindBy (xpath = "//input[@type='number']")
	public WebElement quantity;

	//@FindBy (className = "woocommerce-message")
	@FindBy (css = "div.cart-empty")
	public WebElement removedFromCartMsg;

	@FindBy (linkText = "Undo?")
	public WebElement undo;

	//@FindBy (xpath = "(//td[@class='product-name'])[1]")
	@FindBy (css = "td.product-name > a")
	public WebElement nameOfProductInCart;

	@FindBy (name = "update_cart")
	public WebElement updateCartBtn;

	@FindBy (css = "a.checkout-button")
	public WebElement checkoutBtn;

	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}

	public void clickElement(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

	public String getAttributeValue(WebElement el, String attribute) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}

		return el.getAttribute(attribute);
	}

	public boolean isDisplayed(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.isDisplayed(el);
	}

	public void sendText(String text, WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.insertText(text, el);
	}

	public Object clickElementAndReturnDriver(WebElement el, Object o)   {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
		return o;

	}

}
