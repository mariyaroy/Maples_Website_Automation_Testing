package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: AAFIYA MOL S A

public class ProductsPage {
	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public ProductsPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver=driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText ="Products")
	//@FindBy(xpath = "(//span[@class='link_text'])[3]")
	public WebElement productLink;
	@FindBy(className = "elementor-widget-container")
	public WebElement shopHeadingText;
	
	@FindBy(linkText = "Chicken")
	public WebElement chicken;
	
//	@FindBy(xpath ="//*[@id=\"menu-item-3516\"]/a/span/span")
//	public WebElement chicken;
	
	@FindBy(xpath="//div[@class='elementor-widget-container']")
	public WebElement chickenTitle;
	
	@FindBy(xpath="(//span[@class='link_text'])[16]")
	public WebElement dairy;
	
	@FindBy(xpath="//h1[@class='entry-title']")
	public WebElement dairyTitle;
	
	
	public void clickLinks(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.hover(el);
	}
	public void clickIcons(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.clickElement(el);
	}
	public String getTitle(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		 return reusableFunctions.getTextString(el);
	}
	
	public boolean getPageUrl(String url) {
		return reusableFunctions.checkUrl(url);
	}
}
