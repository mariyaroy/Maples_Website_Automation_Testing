package com.ust.Maples.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

//--------------------BROWSER IMPLEMENTATION--------------------//

public class Browser {

	private static WebDriver driver;

	//--------------------DRIVER FOR CHROME BROWSER--------------------//
	public static WebDriver getChrome() { 

		ChromeOptions coptions = new ChromeOptions();
		coptions.addArguments("--disable-infobars", "--disable-notifications", "--start-maximized");
		driver = new ChromeDriver(coptions);
		//driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		return driver;
	}

	//--------------------DRIVER FOR EDGE BROWSER--------------------//
	public static WebDriver getEdge() { 

		EdgeOptions eoptions = new EdgeOptions();
		eoptions.addArguments("--disable-infobars", "--disable-notifications", "--start-maximized");
		driver = new EdgeDriver(eoptions);
		//driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		return driver;
	}

}

