package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: ARDRA A

public class PrivacyPolicy 
{
	WebDriver driver;
	ReusableFunctions reusableFunctions;
	
	public PrivacyPolicy(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver=driver;
		PageFactory.initElements(driver, this);
		reusableFunctions = new ReusableFunctions(driver);
	}	
	
	@FindBy(xpath="//h2[contains(text(),'Privacy Policy')]")
	public WebElement privacyText;
	
	public PrivacyPolicy getPrivacyPolicyText(WebElement el)
	{
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.getTextString(el);
		return this;
	}
	
	public boolean checkUrlPrivacy(String url)
	{
		return reusableFunctions.checkUrl(url);
	}
	
	public String getPrivacyText(WebElement el)
	{
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}

}
