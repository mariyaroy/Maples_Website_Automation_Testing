package com.ust.Maples.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//--------------------CUCUMBER RUNNER IMPLEMENTATION--------------------//

@CucumberOptions(
		features = {"classpath:Features"},
		glue = {"com.ust.Maples.stepdefinitions"},
		publish = true,
		plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
		//dryRun = true
		//tags = "products"
		)
public class CucumberRunner extends AbstractTestNGCucumberTests{

}
