package com.ust.Maples.stepdefinitions;

import static org.testng.Assert.assertTrue;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.ShopNowPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//AUTHOR: ARDRA A

//--------------------SHOP NOW BUTTON VALIDATION--------------------//

public class ShopNowPageTest
{
	
	HomePage hpage;
	ShopNowPage shopnow;
	WebDriver driver = Hooks.driver;
    Properties prop = Hooks.prop;
	
	@Given("User is on the home page")
	public void user_is_on_the_home_page() {
		hpage=new HomePage(driver);
	}
	@When("User clicks on the Shop Now button")
	public void user_clicks_on_the_shop_now_button() {
		shopnow=(ShopNowPage) hpage.clickElementAndReturnDriver(hpage.shopNowBtn, new ShopNowPage(driver));
	}
	@Then("User should be navigated to the product page")
	public void user_should_be_navigated_to_the_product_page() {
	    assertTrue(shopnow.getUrl(prop.getProperty("ShopNowUrl")),prop.getProperty("ShopNowUrl"));
	   
	   
	}
	@Then("User verifies the title of the product page")
	public void user_verifies_the_title_of_the_product_page() {
		  assertTrue(shopnow.getText(shopnow.shopNowTitle).contains("Heat and Eat Food"));
	 
	}
	
	
}






