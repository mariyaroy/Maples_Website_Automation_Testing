package com.ust.Maples.stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.ContactPage;
import com.ust.Maples.pages.HomePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//AUTHOR: MARIYA ROY

//--------------------CONTACT PAGE VALIDATION--------------------//

public class ContactPageTest {
	WebDriver driver = Hooks.driver;
	HomePage home = new HomePage(driver);
	ContactPage contact;
	Properties prop = Hooks.prop;

	@Given("User is in the home page")
	public void user_is_in_the_home_page() {
		boolean result = home.getUrl(prop.getProperty("BaseUrl"));
		assertTrue(result);
	}
	
	@Given("user clicks the contact tab in the navigation bar")
	public void user_clicks_the_contact_tab_in_the_navigation_bar() {
		home.clickElement(home.contactLink);
		contact = (ContactPage) home.clickElementAndReturnDriver(home.franchise,  new ContactPage(driver));		
		assertEquals(contact.getText(contact.heading), prop.getProperty("ContactPageHeading"));
	}
	
	@When("user clicks the send button")
	public void user_clicks_the_send_button()  {
	    contact.clickElement(contact.sendBtn);
	}
	
	@Then("check whether the form is not submitted for null values")
	public void check_whether_the_form_is_not_submitted_for_null_values() {
		boolean result = home.getUrl(prop.getProperty("ContactPageLink"));
		assertTrue(result, "Submission without data failed!");
	}
	
	@When("user enters {string} in the name field")
	public void user_enters_in_the_name_field(String string) {
	   contact.sendText(string, contact.name);
	}

	@When("user enters {string} in the email field")
	public void user_enters_in_the_email_field(String string) {
		contact.sendText(string, contact.email);
	}

	@When("user enters {string} in the phone field")
	public void user_enters_in_the_phone_field(String string) {
		contact.sendText(string, contact.phone);
	}

	@When("user enters {string} in the message field")
	public void user_enters_in_the_message_field(String string) {
		contact.sendText(string, contact.message);
	}

	@Then("validate the result based on the {string} of data")
	public void validate_the_result_based_on_the_of_data(String string) throws InterruptedException {
	    if(string.equals("invalid")) {
	    	assertTrue(contact.getUrl(prop.getProperty("ContactPageLink")));
	    }
	    else if (string.equals("valid")) {
	    	Setup.wait(4);
	    	String result = contact.getText(contact.successMsg);
	    	assertEquals( result, prop.getProperty("ContactPageValidSubmissionMsg"));
	    }
	}

	
}
