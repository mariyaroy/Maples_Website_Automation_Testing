package com.ust.Maples.tests;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: MARIYA ROY

//--------------------HOME PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class HomePageTest extends Setup {
	
	public WebDriver driver;
	public HomePage home;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));		
		home = new HomePage(driver);
	}

	@Test (priority = 0, description = "Verifying the URL, title, logo and copyright text in the website", enabled = false)
	public void verifyHomePage() {
		driver.get(prop.getProperty("BaseUrl"));
		
		assertTrue(home.getUrl(prop.getProperty("BaseUrl")), "Failed to load home page!");
		assertTrue(home.getTitle(prop.getProperty("TitleAlt")), "Title mismatch!");
		assertTrue(home.isDisplayed(home.logo), "Logo is not displayed!");
		assertTrue(home.getText(home.copyRight).contains(prop.getProperty("Copyright")));
	}
	
	@Test (priority = 0, description = "Verifying the URL, title, logo and copyright text in the website")
	public void verifyHomePageNew() {
		driver.get(prop.getProperty("BaseUrl"));
		
		assertTrue(home.getUrl(prop.getProperty("BaseUrl")), "Failed to load home page!");
		//assertTrue(home.getTitle(prop.getProperty("Title")), "Title mismatch!");
		assertTrue(home.getTitle(prop.getProperty("TitleAlt")), "Title mismatch!");
		assertTrue(home.isDisplayed(home.logo), "Logo is not displayed!");
		assertTrue(home.getText(home.copyRight).contains(prop.getProperty("Copyright")));
	}
		
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}