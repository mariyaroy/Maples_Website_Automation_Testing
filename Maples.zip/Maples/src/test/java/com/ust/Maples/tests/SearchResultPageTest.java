package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.SearchResultPage;
import com.ust.Maples.testlistener.ExtentReportListener;

//AUTHOR: ARDRA A

//--------------------SEARCH RESULT PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class SearchResultPageTest extends Setup
{
 
	public WebDriver driver;
	public HomePage home;
	public SearchResultPage searchResult;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));		
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
		 
	}

	@Test (priority = 0, description = "Verifying the product search")
	public void verifySearch() 
	{
		driver.get(prop.getProperty("BaseUrl"));
		searchResult=(SearchResultPage) home.clickElementAndReturnDriver(home.searchBar, new SearchResultPage(driver));
		home.sendText(prop.getProperty("SearchProductName"),home.searchBar);
		home.clickElement(home.searchIcon);
		assertEquals(searchResult.ResultgetTitle(searchResult.SearchResultTitle),prop.getProperty("SearchProduct"));
		
	}
	
	@Test (priority = 1, description = "Verifying the product search with Invalid product name")
	public void verifyInvalidSearch() 
	{
		home.clickElement(home.searchBar);
		home.sendText(prop.getProperty("SearchInvalidProductName"),home.searchBar);
		home.clickElement(home.searchIcon);
		assertEquals(searchResult.ResultgetTitle(searchResult.SearchInvalidResult),prop.getProperty("SearchInvalidResult"));
		
	}
	
	@Test (priority = 2, description = "Verifying the product search with No product name")
	public void verifySearchNullProduct() 
	{
		home.clickElement(home.searchBar);
		home.sendText(prop.getProperty("SearchNullProduct"),home.searchBar);
		home.clickElement(home.searchIcon);
		assertTrue(searchResult.ResultgetTitle(searchResult.SearchNullResult).contains(prop.getProperty("SearchNullProduct")));
		
	}
	
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}
