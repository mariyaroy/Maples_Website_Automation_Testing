package com.ust.Maples.stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.OurProductsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//AUTHOR: MARIYA ROY

//--------------------'OUR PRODUCTS' LINKS VALIDATION--------------------//

public class OurProductsPageTest {
	
	public WebDriver driver = Hooks.driver;
	public Properties prop = Hooks.prop;
	public HomePage home = new HomePage(driver);
	public OurProductsPage products = new OurProductsPage(driver);
	
	@Given("User is in the landing page")
	public void user_is_in_the_landing_page() {
		boolean result = home.getUrl(prop.getProperty("BaseUrl"));
		assertTrue(result);	}
	
	@When("user clicks a {string}")
	public void user_clicks_a(String string) {
	    products.clickLink(string);	    
	}
	
	@Then("the website navigates to corresponding {string}")
	public void the_website_navigates_to_corresponding(String string) {
		String url = products.getUrl();
		assertTrue(url.contains(string));
	}
	
	@Then("the {string} of the page is validated")
	public void the_of_the_page_is_validated(String string) {
		String heading = products.getText(products.heading);
	    assertEquals(heading, string);
	}

 
}
