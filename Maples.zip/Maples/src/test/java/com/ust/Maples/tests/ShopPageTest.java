package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.ShopPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: ARDRA A

//--------------------SHOP PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class ShopPageTest extends Setup
{
	public WebDriver driver;
	public HomePage home;
	public ShopPage shop;

	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{
		driver = invokeBrowser(prop.getProperty("Browser"));
		driver.get(prop.getProperty("BaseUrl"));

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7)); // IMPLICIT WAIT
		Thread.sleep(10000);
		home = new HomePage(driver);
		shop=(ShopPage) home.clickElementAndReturnDriver(home.productsLink, new ShopPage(driver));
		
	}

	//CATEGORY SHOP 

	@Test(priority = 1,description = "Checking the category")
	public void verifyCategory() 
	{
		shop.clickElement(shop.categorySelect);
		assertEquals(shop.getText(shop.categoryName),prop.getProperty("CategoryName"));
		home.clickElement(home.homeLink);
	}

	//BRANDS

	@Test(priority = 2,description = "Checking the Brands", enabled = false)
	public void verifyBrands() throws InterruptedException 
	{
		//wait(10);
		home.clickElement(home.productsLink);
		shop.clickElement(shop.brands);

		assertTrue(shop.getText(shop.brandsName).contains(prop.getProperty("BrandName")));

	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}
