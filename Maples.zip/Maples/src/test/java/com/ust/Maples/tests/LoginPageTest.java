package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.dataproviders.DataProviderUtility;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.LoginPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: AAFIYA MOL S A

//--------------------LOGIN PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class LoginPageTest extends Setup {

	public WebDriver driver;
	public HomePage home;
	public LoginPage login;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		login = new LoginPage(driver);
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
	}
	@Test (priority = 0, description = "Login link validation")
	public void verifyLoginTitle() {
		home.clickElement(home.loginLink);
		String title=login.getText(login.myAccTitle);
		assertTrue(true, title);

	}

	@Test (priority = 1)
	public void verifyNullLogin() {
		login.clickButton(login.logButton);
		assertEquals(login.getText(login.nullLoginText), prop.getProperty("NullLoginMsg"));
	}

	// USING DATAPROVIDER
	@Test (priority = 2, dataProvider = "LoginData", dataProviderClass = DataProviderUtility.class,description = "Login button validation")
	public void verifyLogin(String username, String password , String validation) throws InterruptedException{
		login.sendText(username, login.uname); // ENTERING EMAIL ID
		login.sendText(password, login.pswd);
		login.clickButton(login.logButton); // CLICKING THE LOGIN BUTTON


		if(validation.equals("valid")) {
			assertTrue(login.getText(login.successText).contains("Hello"));
			login.clickButton(login.logoutButton);
		}
		else if(validation.equals("invalid")) {
			assertTrue(login.getText(login.errorText).contains("Error"));
		}
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}


